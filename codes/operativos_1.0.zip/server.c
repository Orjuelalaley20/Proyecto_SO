/* 
Autor: M. Curiel
funcion: Ilustra la creaci'on de pipe nominales. 
Nota: todas las llamadas al sistema no estan validadas.
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include "nom.h"


#define TAMNOM 20

int main (int argc, char **argv)
{
  int  fd, fd1,  pid, n, cuantos,res,creado=0;
  datap datos;
 
  
  mode_t fifo_mode = S_IRUSR | S_IWUSR;
  
  // Creacion del pipe inicial, el que se recibe como argumento del main
  if (mkfifo (argv[1], fifo_mode) == -1) {
     perror("Server mkfifo");
     exit(1);
  }
   
  // Abre el pipe. No olviden validar todas las llmadas al sistema. 
  fd = open (argv[1], O_RDONLY);
  
  // El otro proceso (nom1) le envia el nombre para el nuevo pipe y el pid. 
  cuantos = read (fd, &datos, sizeof(datos));
  if (cuantos == -1) {
     perror("proceso lector:");
     exit(1);
  }
   printf ("Server lee el string %s\n", datos.segundopipe);
   printf ("Server el pid %d\n", datos.pid );

   do { 
      if ((fd1 = open(datos.segundopipe, O_WRONLY)) == -1) {
         perror(" Server Abriendo el segundo pipe ");
         printf(" Se volvera a intentar despues\n");
         sleep(5); //los unicos sleeps que deben colocar son los que van en los ciclos para abrir los pipes.         
      } else creado = 1; 
   }  while (creado == 0);


    // Se escribe un mensaje para el  proceso (nom1)
   
   write(fd1, "hola", 5);

      
   exit(0);

}





