#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include "usuario.h"

int main (int argc, char **argv)
{

  userT datos;
  int creado;
  int fd;//,fd1;
  //char bajada[10],mensaje[60];
  //mode_t fifo_mode = S_IRUSR | S_IWUSR;

  datos.ID_usuario=1;
  strcpy(datos.tweet,"Platano torino");

  do {
     fd = open("enviar", O_WRONLY);
     if (fd == -1) {
         perror("pipe");
         printf(" Se volvera a intentar despues\n");
   sleep(10);
     } else creado = 1;
  } while (creado == 0);

  write(fd, &datos , sizeof(datos));
/*
  sprintf(bajada,"pipe%d",datos.ID_usuario);
  // Se crea un segundo pipe para la comunicacion con el server.
  unlink(bajada);
  if (mkfifo (bajada, fifo_mode) == -1) {
     perror("Client  mkfifo");
     exit(1);
  }

  creado = 0;
  do {
     if ((fd1 = open(bajada, O_RDONLY)) == -1) {
        perror(" Cliente  Abriendo el segundo pipe. Se volvera a intentar ");
        sleep(5);
     } else creado = 1;
   } while (creado == 0);

   read(fd1, mensaje, 60);
   printf("El proceso cliente termina y lee %s \n", mensaje);
*/

  exit(0);
}
