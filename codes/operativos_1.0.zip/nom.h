typedef  struct data {
    char segundopipe[20];
    int pid;

} datap;
