#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <unistd.h>
#include "usuario.h"

int main (int argc, char **argv)
{

  int pipe_1,cuantos,fd1,creado;
  userT datos;
  mode_t fifo_mode = S_IWUSR | S_IRUSR;
  char nombrePipe[7] = "enviar";
  //char platano[60]="Soy un platano... Sou un puto platano.\n\nHijo de puta";
  //char bajada[10];
  //strcpy(nombrePipe,"enviar");

  unlink(nombrePipe);
  if (mkfifo (nombrePipe, fifo_mode) == -1) {
     perror("Server mkfifo");
     exit(1);
  }
  pipe_1=open(nombrePipe,O_RDONLY);

  cuantos = read (pipe_1, &datos, sizeof(datos));
  if (cuantos == -1) {
     perror("proceso lector:");
     exit(1);
  }

  printf ("Server lee el string %s\n", datos.tweet);
  printf ("Server el id %d\n", datos.ID_usuario );
/*
  sprintf(bajada,"pipe%d",datos.ID_usuario);
  do {
     if ((fd1 = open(bajada, O_WRONLY)) == -1) {
        perror(" Server Abriendo el segundo pipe ");
        printf(" Se volvera a intentar despues\n");
        sleep(5); //los unicos sleeps que deben colocar son los que van en los ciclos para abrir los pipes.
     } else creado = 1;
  }  while (creado == 0);

  write(fd1,platano, 60);
  */
  exit(0);
}
