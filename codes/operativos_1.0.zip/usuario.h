typedef  struct user {
  int ID_usuario;
  char tweet[200];
} userT;
